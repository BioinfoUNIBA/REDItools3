# REDItools3
A new REDItools implementation to speed-up the RNA editing profiling in massive RNAseq data

# Installation
Install from PyPi.
`pip install REDItools3`

Use the whl file under the dist directory.
`pip install dist/reditools-0.1-py3-none-any.whl`

# Usage
Once installed, reditools can be run from the commandline.
`python -m reditools`
