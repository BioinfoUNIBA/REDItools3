from types import TracebackType
from typing import Iterator

from pysam.libcfaidx import FastaFile as PysamFastaFile


class RTFastaFile:
    """
    A wrapper around pysam.FastaFile for genomic sequence access.
    """

    def __init__(self, filename: str) -> None:
        """
        Initialize the RTFastaFile.

        Parameters
        ----------
        *args
            Arguments passed to pysam.FastaFile.
        **kwargs
            Keyword arguments passed to pysam.FastaFile.
        """
        self.pysam_fasta_file = PysamFastaFile(filename)

    def __enter__(self):  # type: ignore
        return self

    def __exit__(
        self,
        exc_type: type,
        exc_value: Exception,
        traceback: TracebackType,
    ) -> None:
        """
        Exit the runtime context related to this object.

        Parameters
        ----------
        exc_type : type | None
            The exception type.
        exc_value : Exception | None
            The exception value.
        traceback : TracebackType | None
            The traceback.
        """
        self.pysam_fasta_file.close()

    def get_base(self, contig: str, *position: int) -> Iterator[str]:
        """
        Retrieve bases at specified positions from a contig.

        Parameters
        ----------
        contig : str
            The name of the contig or chromosome.
        *position : int
            One or more 0-based positions to retrieve bases for.

        Returns
        -------
        Iterator[str]
            An iterator over the upper-case bases at the specified positions.

        Raises
        ------
        KeyError
            If the contig is not found in the FASTA file.
        IndexError
            If a position is outside the bounds of the contig.
        """

        if contig not in self.pysam_fasta_file:
            if contig.startswith('chr'):
                new_contig = contig.replace('chr', '')
            else:
                new_contig = f'chr{contig}'
            if new_contig not in self.pysam_fasta_file:
                raise KeyError(
                    f'Reference name {contig} not found in FASTA file.',
                )
            contig = new_contig
        sorted_pos = sorted(position)
        seq = self.pysam_fasta_file.fetch(
            contig,
            sorted_pos[0],
            sorted_pos[-1] + 1,
        )
        try:
            return (seq[_ - sorted_pos[0]].upper() for _ in position)
        except IndexError as exc:
            raise IndexError(
                f'Base position {position} is outside the bounds of ' +
                '{contig}. Are you using the correct reference?',
            ) from exc
